﻿// See https://aka.ms/new-console-template for more information
using ProyectoPlataformaServices;

PlataformaStreaming miApp = new PlataformaStreaming();
Console.WriteLine("Bienvenido a la aplicacion de Streaming");

int opcion = 10;
MostrarInstrucciones();
opcion = int.Parse(Console.ReadLine());

while(opcion != 0)
{
    switch (opcion)
    {
        case 1:
            {
                break;
            }
        case 2:
            {
                break;
            }
        case 3:
            {
                break;
            }
        case 4:
            {
                break;
            }
        default: break;
    }

    MostrarInstrucciones();
    opcion = int.Parse(Console.ReadLine());
}

void MostrarInstrucciones()
{
    Console.WriteLine("Ingrese un numero para continuar");
    Console.WriteLine("1.Agregar Usuario");
    Console.WriteLine("2.Agregar produccion");
    Console.WriteLine("3.Agregar visualizacion");
    Console.WriteLine("4.Mostrar visualizacion");
    Console.WriteLine("0. Salir");
}

void AgregarUsuario()
{
    Usuario nuevoUsuario = new Usuario();

    Console.WriteLine("Ingrese el nombre del usuario");
    string nom = Console.ReadLine();

    Console.WriteLine("Ingrese fecha de nacimiento. Formato: MM/DD/YYYY");
    DateTime fechaRe = DateTime.Parse(Console.ReadLine());

    Console.WriteLine("Ingrese el nivel de suscripcion");
    foreach (Suscripcion su in Enum.GetValues(typeof(Suscripcion)))
    {
        Console.WriteLine($"{(int)su}.{su}");
    }
    Suscripcion susU = (Suscripcion)int.Parse(Console.ReadLine());

    miApp.AgregarUsuario(nuevoUsuario);
}

void AgregarVisualizacion()
{
    Console.WriteLine("Ingrese un codigo de usuario");
    int codU = int.Parse(Console.ReadLine());

    miApp.RegistrarVisualizacion(codU);
}

void MostrarVisualizacion()
{

}


