﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPlataformaServices
{
    public class Serie : Produccion
    {
        public int NumeroTemporadas { get; set; }
        public int DuracionCap { get; set; }

        public override string DescribirProduccion()
        {
            return $"{NombreProduccion} es una serie que tiene {NumeroTemporadas} temporadas, " +
                $"con una duración promedio de {DuracionCap} minutos por episodio, de género {GeneroProduccion}.";
        }

    }
}
