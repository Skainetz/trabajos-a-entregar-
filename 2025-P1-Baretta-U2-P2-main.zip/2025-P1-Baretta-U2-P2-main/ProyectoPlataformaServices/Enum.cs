﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPlataformaServices
{
    public enum Suscripcion
    {
        Gratuito = 1, Básico, Premium
    }

    public enum Genero
    {
        Acción, Comedia, Drama, Terror, Documental, Fantasia
    }

}
