﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPlataformaServices
{
    public class Pelicula : Produccion
    {
        public int Duracion { get; set; }
        public override string DescribirProduccion()
        {
            return $"{NombreProduccion} es una película de {Duracion} minutos de duración, de género {GeneroProduccion}.";
        }
    }
}
