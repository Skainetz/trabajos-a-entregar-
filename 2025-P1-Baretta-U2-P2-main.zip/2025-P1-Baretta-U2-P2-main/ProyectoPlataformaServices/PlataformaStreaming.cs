﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPlataformaServices
{
    public  class PlataformaStreaming
    {
        private List<Usuario> ListaUsuarios {  get; set; }
        private List<Produccion> ListaProducciones { get; set; }
        private List<Visualizacion> ListaVisualizaciones { get; set; }
        public PlataformaStreaming()
        {
            ListaUsuarios = new List<Usuario>();
            ListaVisualizaciones = new List<Visualizacion>();
            ListaProducciones = new List<Produccion>();
        }

        public void AgregarUsuario(Usuario nuevoUsuario)
        {
            nuevoUsuario.CodigoUsuario = ListaUsuarios.Count;
            ListaUsuarios.Add(nuevoUsuario);
        }

        public List<string> MostrarProducciones(string nombreP)
        {
            return ListaProducciones.Where(p => p.NombreProduccion == nombreP.ToLower()).Select(p => p.DescribirProduccion()).ToList();
        }

        public List<string> MostrarProducciones()
        {
            return ListaProducciones.Select(p => p.DescribirProduccion()).ToList() ;
        }

        public void AgregarProduccion(Produccion nuevaProduccion)
        {
           if(nuevaProduccion != null && nuevaProduccion.Reseña.Length < 150)
            {
                nuevaProduccion.NombreProduccion = nuevaProduccion.NombreProduccion.ToLower();
                ListaProducciones.Add(nuevaProduccion);
            }
        }

        public void RegistrarVisualizacion(int codigoUsuario)
        {
            Visualizacion nuevaVisualizacion = new Visualizacion();
            nuevaVisualizacion.CodigoUsuario = codigoUsuario;

            ListaVisualizaciones.Add(nuevaVisualizacion);
        }
    }
}
