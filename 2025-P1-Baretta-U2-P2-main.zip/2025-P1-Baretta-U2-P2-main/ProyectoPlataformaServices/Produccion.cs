﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPlataformaServices
{
    public abstract class Produccion
    {
        public string NombreProduccion { get; set; }
        public List<string> ListaProductores { get; set; }
        public int AñoPublicacion { get; set; }
        public string Reseña { get; set; }
        public Genero GeneroProduccion { get; set; }

        public virtual string DescribirProduccion()
        {
            return "";
        }
    }
}
