﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPlataformaServices
{
    public class Visualizacion
    {
        public int CodigoVisualizacion { get; set; }
        public DateTime FechaVisualizacion { get; set; }
        public int CodigoUsuario { get; set; }

        public Visualizacion() {
            FechaVisualizacion = DateTime.Now;
        }

    }
}
