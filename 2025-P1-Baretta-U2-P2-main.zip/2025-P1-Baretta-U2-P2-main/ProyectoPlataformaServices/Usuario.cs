﻿namespace ProyectoPlataformaServices
{
    public class Usuario
    {
        public int CodigoUsuario { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaRegistro { get; set; }
        public Suscripcion NivelSuscripcion { get; set; }

    }
}